/* ═══════════════════════════════════════════════════════════════
   CAMADA: DADOS
   ARQUIVO: reacoes-livres-expansao-6.js
   ───────────────────────────────────────────────────────────────
   Mais reações do Laboratório, adicionadas ao banco REACOES_LIVRES
   nesta expansão do catálogo (ver reacoes-livres-base.js para a
   explicação completa da técnica de mesclagem via IIFE).
   Depende de: js/data/reacoes-livres-base.js (REACOES_LIVRES já
               precisa existir).
═══════════════════════════════════════════════════════════════ */

'use strict';

/* ── 5 compostos adicionais para atingir exatamente 100 ── */
(function(){
  var exp5 = [
  {
    id:'cr2o3', formula:'Cr₂O₃', formulaId:'Cr2O3',
    nome:'Óxido de Cromo III', funcao:'oxido', categoria:'Óxidos Anfóteros',
    massa:'152,00 g/mol', Tf:2435, Tb:4000, densidade:'5,22 g/cm³',
    solubilidade:'Insolúvel em água; dissolve em ácidos fortes',
    ph:'neutro-anfótero', nomenclatura:'Trióxido de dicromo (esmeraldina)',
    badges:['anfótero','verde','pigmento','cromo III'],
    geometria:'Coríndon (hexagonal)', ligacao:'Iônica (Cr³⁺ e O²⁻)',
    equacao:'Cr₂O₃ + 6 HCl → 2 CrCl₃ + 3 H₂O',
    reacao:'4 Cr(s) + 3 O₂(g) → 2 Cr₂O₃(s)',
    lewis:'generico', uso:'Pigmento verde (tinta, plástico, vidro), polimento de metais (pasta de Cr₂O₃), catalisador',
    curiosidade:'O Cr₂O₃ (verde) é muito menos tóxico que o Cr(VI) (laranja/amarelo). A "pasta verde" usada para afiar navalhas e bisturis é Cr₂O₃ fino. Rubi = Al₂O₃ com Cr³⁺ (vermelho); Esmeralda = Be₃Al₂(SiO₃)₆ com Cr³⁺ (verde).',
    descricao:'Óxido anfótero de Cr(III), pó verde intenso. Ponto de fusão altíssimo (2435°C). Pigmento verde industrial. Muito mais estável e menos tóxico que compostos de Cr(VI). Forma-se na superfície do aço inoxidável (camada passiva).',
  },
  {
    id:'tio2', formula:'TiO₂', formulaId:'TiO2',
    nome:'Dióxido de Titânio', funcao:'oxido', categoria:'Óxidos Anfóteros',
    massa:'79,87 g/mol', Tf:1843, Tb:2972, densidade:'4,23 g/cm³',
    solubilidade:'Insolúvel em água; dissolve em H₂SO₄ concentrado quente e HF',
    ph:'neutro', nomenclatura:'Dióxido de titânio (titânia)',
    badges:['branco','fotocatalisador','protetor solar','pigmento'],
    geometria:'Rutilo (tetragonal) ou anatásio', ligacao:'Iônica (Ti⁴⁺ e O²⁻)',
    equacao:'TiO₂ →(UV)→ e⁻(BC) + h⁺(BV)   [fotocatálise]',
    reacao:'TiCl₄(l) + 2 H₂O(g) → TiO₂(s) + 4 HCl(g)',
    lewis:'generico', uso:'Pigmento branco (tintas, plásticos, papel), protetor solar (bloqueio UV), fotocatálise (purificação de ar e água)',
    curiosidade:'TiO₂ é o pigmento branco mais usado no mundo — está em quase toda tinta branca, creme dental e protetor solar. A anatásio (TiO₂) sob UV decompõe poluentes orgânicos e mata bactérias — painéis autolimpantes e purificadores de ar.',
    descricao:'Óxido de Ti(IV), branco intenso. Maior índice de refração entre os óxidos comuns (n=2,55 rutilo) — por isso brilhante opaco. Fotocatalisador: bandgap 3,2 eV absorve UV, gera radicais •OH que oxidam poluentes.',
  },
  {
    id:'na2o2', formula:'Na₂O₂', formulaId:'Na2O2',
    nome:'Peróxido de Sódio', funcao:'oxido', categoria:'Peróxidos',
    massa:'77,98 g/mol', Tf:675, Tb:null, densidade:'2,81 g/cm³',
    solubilidade:'Reage violentamente com água → NaOH + H₂O₂',
    ph:'> 13', nomenclatura:'Peróxido de sódio',
    badges:['peróxido','oxidante','gerador O₂','submarinos'],
    geometria:'Iônica (O₂²⁻ e Na⁺)', ligacao:'Iônica (Na⁺ e O₂²⁻)',
    equacao:'2 Na₂O₂ + 2 H₂O → 4 NaOH + O₂   [geração de O₂]',
    reacao:'2 Na(s) + O₂(g) → Na₂O₂(s)   [queima em excesso de O₂]',
    lewis:'generico', uso:'Gerador de O₂ em submarinos e minas (reage com CO₂ e H₂O liberando O₂), branqueamento, oxidante',
    curiosidade:'Em submarinos: Na₂O₂ + CO₂ → Na₂CO₃ + O₂. O tripulante expira CO₂, o cartucho absorve e libera O₂. Uma equação que sustenta vida submersa! Também bleaching de tecidos: Na₂O₂ + H₂O → NaOH + H₂O₂.',
    descricao:'Peróxido do sódio — contém o íon O₂²⁻ (peroxídico). Forma-se quando Na queima com excesso de O₂. Usado para regenerar ar em ambientes fechados (submarinos, minas): absorve CO₂ e H₂O, libera O₂.',
  },
  {
    id:'caso3', formula:'CaSO₃', formulaId:'CaSO3',
    nome:'Sulfito de Cálcio', funcao:'sal', categoria:'Sais de Cálcio',
    massa:'120,17 g/mol', Tf:null, Tb:null, densidade:'2,51 g/cm³',
    solubilidade:'Pouco solúvel (0,0043 g/100 mL a 18°C)',
    ph:'8–10', nomenclatura:'Sulfito de cálcio',
    badges:['insolúvel','dessulfurização','FGD','precipitado'],
    geometria:'Iônica; SO₃²⁻ piramidal', ligacao:'Iônica (Ca²⁺ e SO₃²⁻)',
    equacao:'CaSO₃ ⇌ Ca²⁺ + SO₃²⁻   Kps = 3,1×10⁻⁷',
    reacao:'CaO(s) + SO₂(g) → CaSO₃(s)   [dessulfurização de gases]',
    lewis:'sal_ionico', uso:'Dessulfurização de gases de combustão (FGD — Flue Gas Desulfurization), branqueamento de papel',
    curiosidade:'Usinas termelétricas a carvão injetam CaO (calcário calcinado) nos gases de combustão: CaO + SO₂ → CaSO₃, reduzindo a emissão de SO₂ (chuva ácida) em até 95%. Produção mundial: milhões de toneladas/ano como subproduto.',
    descricao:'Precipitado branco pouco solúvel. Produzido em larga escala no processo FGD (dessulfurização de gases) de termelétricas a carvão e óleo. Pode ser oxidado a CaSO₄ (gesso) vendável para a construção civil.',
  },
  {
    id:'zns', formula:'ZnS', formulaId:'ZnS',
    nome:'Sulfeto de Zinco', funcao:'sal', categoria:'Sais de Enxofre',
    massa:'97,47 g/mol', Tf:1700, Tb:null, densidade:'4,09 g/cm³',
    solubilidade:'Insolúvel em água (Kps = 1,6×10⁻²⁴)',
    ph:'neutro', nomenclatura:'Sulfeto de zinco (blenda, esfalerita)',
    badges:['insolúvel','luminescente','mineral','blenda'],
    geometria:'Cúbica (blenda de zinco) ou hexagonal (wurtzita)', ligacao:'Covalente com caráter iônico',
    equacao:'ZnS ⇌ Zn²⁺ + S²⁻   Kps = 1,6×10⁻²⁴',
    reacao:'Zn(s) + S(s) →(Δ)→ ZnS(s)   [síntese direta]',
    lewis:'sal_ionico', uso:'Pigmento branco, tela de raios catódicos (CRT), cintilador, material fosforescente (visão noturna)',
    curiosidade:'ZnS dopado com Cu emite luz verde ao ser excitado por raios-X ou elétrons — foi o material das telas de TVs e monitores CRT durante décadas. ZnS:Ag emite azul. Ainda usado em telas de osciloscópio e detectores de radiação.',
    descricao:'Mineral esfalerita (blenda de zinco) — principal minério de Zn. Semicondutor de bandgap largo (3,6 eV). Fosforescente quando dopado. Precipitado branco em análise qualitativa: H₂S + Zn²⁺ (pH neutro) → ZnS↓.',
  },
  ];

  exp5.forEach(function(c){
    var estado='—';
    if(c.Tf!==null&&c.Tb!==null){ if(c.Tf>25) estado='Sólido (25 °C)'; else if(c.Tb<25) estado='Gasoso (25 °C)'; else estado='Líquido (25 °C)'; }
    else if(c.Tf===null){ estado='Aquoso / Instável'; }
    else if(c.Tf>25){ estado='Sólido (25 °C)'; }
    c.estado=estado; c.pfStr=c.Tf!==null?c.Tf+' °C':'—'; c.peStr=c.Tb!==null?c.Tb+' °C':'— (decompõe)';
    CATALOGO_SIQI.push(c);
  });
})();

