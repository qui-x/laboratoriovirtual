/* ═══════════════════════════════════════════════════════════════
   CAMADA: DADOS
   ARQUIVO: reacoes-redox.js
   ───────────────────────────────────────────────────────────────
   As reações de oxirredução cadastradas para o módulo 3 (Redox):
   estados de oxidação de cada espécie, semirreações de oxidação e
   redução, e o balanceamento completo pelo método do íon-elétron.
   Depende de: nada. Usado por: js/redox/*.
═══════════════════════════════════════════════════════════════ */

'use strict';

/* ═══════════════════════════════════════════════════════════════════
   REACOES_REDOX — Módulo 3 (Reações de Oxirredução)
   Plano de Ação SIQI Modular (2026)
   ---------------------------------------------------------------------
   redox_001 — a equação '4 Fe(s) + 3 O₂(g) → 2 Fe₂O₃(s)' é EXATAMENTE
     o campo `equacao` do composto 'fe2o3' em CATALOGO_SIQI (acima).
   redox_002 — a semirreação de redução 'MnO₄⁻ + 5e⁻ + 8H⁺ → Mn²⁺ +
     4H₂O' vem do campo `reacao` do composto 'kmno4'; a oxidação de
     Fe²⁺ → Fe³⁺ é mencionada no campo `curiosidade` de 'feso4'.

   Cálculo de balanceamento (método do íon-elétron / meia-reação):
     1. Escrever as duas semirreações com elétrons explícitos.
     2. Calcular o MMC do nº de elétrons de cada semirreação.
     3. Multiplicar cada semirreação pelo fator que iguala os
        elétrons perdidos aos ganhos.
     4. Somar as semirreações; os elétrons se cancelam.

   Referências: Brown, LeMay & Bursten (2012) "Chemistry: The Central
   Science", 12ª ed., Cap. 20 (Eletroquímica); Zumdahl & Zumdahl
   (2009) "Chemistry", 8ª ed., Cap. 17-19; NIST WebBook.

   BNCC: Habilidade EF09CI05 (estequiometria via balanceamento de
   elétrons transferidos).
═══════════════════════════════════════════════════════════════════ */
var REACOES_REDOX = [

  {
    id: 'redox_001',
    titulo: 'Combustão do Ferro (formação da ferrugem)',
    equacao_desbalanceada: 'Fe(s) + O₂(g) → Fe₂O₃(s)',
    ambiente: 'neutro',
    oxidacao_estados: {
      Fe: { inicial: 0, final: 3 },
      O: { inicial: 0, final: -2 },
    },
    semireacoes: {
      oxidacao: { especie: 'Fe', estado_inicial: 0, estado_final: 3, mudanca: 3, eletrons: 3, equacao: 'Fe → Fe³⁺ + 3 e⁻' },
      reducao: { especie: 'O₂', estado_inicial: 0, estado_final: -2, mudanca: 2, eletrons: 4, equacao: 'O₂ + 4 e⁻ → 2 O²⁻' },
    },
    coeficientes: { Fe: 4, O2: 3, Fe2O3: 2 },
    equacao_balanceada: '4 Fe(s) + 3 O₂(g) → 2 Fe₂O₃(s)',
    dificuldade: 'basico',
    descricao: 'O ferro metálico (Fe⁰) é oxidado a Fe³⁺ enquanto o oxigênio molecular (O₂⁰) é reduzido a O²⁻, formando o óxido de ferro(III) — a ferrugem.',
    aplicacao: 'Corrosão de estruturas de ferro/aço expostas ao ar úmido; base da reação termoita (Fe₂O₃ + Al) usada para soldar trilhos ferroviários.',
    fonte: 'Brown et al. (2012), Cap. 20; dado consistente com o campo `equacao` do composto Fe₂O₃ em CATALOGO_SIQI.',
  },

  {
    id: 'redox_002',
    titulo: 'Permanganato oxidando íons Ferro(II) em meio ácido',
    equacao_desbalanceada: 'Fe²⁺(aq) + MnO₄⁻(aq) + H⁺(aq) → Fe³⁺(aq) + Mn²⁺(aq) + H₂O(l)',
    ambiente: 'acido',
    oxidacao_estados: {
      Fe: { inicial: 2, final: 3 },
      Mn: { inicial: 7, final: 2 },
    },
    semireacoes: {
      oxidacao: { especie: 'Fe²⁺', estado_inicial: 2, estado_final: 3, mudanca: 1, eletrons: 1, equacao: 'Fe²⁺ → Fe³⁺ + e⁻' },
      reducao: { especie: 'MnO₄⁻', estado_inicial: 7, estado_final: 2, mudanca: 5, eletrons: 5, equacao: 'MnO₄⁻ + 8 H⁺ + 5 e⁻ → Mn²⁺ + 4 H₂O' },
    },
    coeficientes: { Fe2: 5, MnO4: 1, H: 8, Fe3: 5, Mn2: 1, H2O: 4 },
    equacao_balanceada: '5 Fe²⁺(aq) + MnO₄⁻(aq) + 8 H⁺(aq) → 5 Fe³⁺(aq) + Mn²⁺(aq) + 4 H₂O(l)',
    dificuldade: 'intermediaria',
    descricao: 'Titulação redox clássica: o permanganato (roxo intenso, Mn⁺⁷) é reduzido a Mn²⁺ (quase incolor) ao oxidar o Fe²⁺ a Fe³⁺. A viragem de cor (roxo → incolor) marca o ponto final da titulação sem indicador externo.',
    aplicacao: 'Permanganatometria — determinação quantitativa da concentração de Fe²⁺ em amostras (análise volumétrica).',
    fonte: 'Brown et al. (2012), Cap. 20 (titulação redox); dado consistente com o campo `reacao` do composto KMnO₄ e o campo `curiosidade` do composto FeSO₄ em CATALOGO_SIQI.',
  },

];

