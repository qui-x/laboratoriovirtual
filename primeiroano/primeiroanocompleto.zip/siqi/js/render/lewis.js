/* ═══════════════════════════════════════════════════════════════
   CAMADA: RENDERIZAÇÃO
   ARQUIVO: lewis.js
   ───────────────────────────────────────────────────────────────
   Desenha a estrutura de Lewis simplificada de um composto em SVG:
   os elementos primitivos (átomo, ligação, rótulo, par de elétrons)
   e uma função de desenho por tipo de composto (haloidrácido,
   oxigenado, base, base fraca, sal, sal colorido, óxido básico/ácido,
   e um fallback genérico).
   Depende de: nada além dos dados do composto (já processados).
   Usado por: js/nomenclatura/desafio.js, o módulo Ficha.
═══════════════════════════════════════════════════════════════ */

'use strict';

/* ════════════════════════════════════════════════════════════════
   11. LEWIS SVG
════════════════════════════════════════════════════════════════ */
function desenharLewis(formula, c, svgOverride){
  var svg=svgOverride||$('lewis-svg'); if(!svg) return;
  var leg=svgOverride?null:$('lewis-legenda');
  while(svg.firstChild) svg.removeChild(svg.firstChild);

  var tipo=c.lewis||'generico';
  var fn={ acido_haloidro:lewisHaloidro, acido_oxigenado:lewisOxigenado,
    base_forte:lewisBase, base_fraca:lewisBaseFraga,
    sal_ionico:lewisSal, sal_colorido:lewisSalColorido,
    oxido_basico:lewisOxidoBasico, oxido_acido:lewisOxidoAcido, generico:lewisGenerico };
  (fn[tipo]||fn.generico)(svg, formula);
  if(leg){ var f2=FUNCAO_META[c.funcao]||{}; leg.textContent=(f2.label||c.funcao)+' — estrutura simplificada'; }
}

function svgEl(tag,attrs){
  var el=document.createElementNS('http://www.w3.org/2000/svg',tag);
  Object.keys(attrs).forEach(function(k){ el.setAttribute(k,attrs[k]); });
  return el;
}

function atom(svg,x,y,sym,fill,r){
  r=r||17;
  svg.appendChild(svgEl('circle',{cx:x,cy:y,r:r,fill:fill,stroke:'var(--bdr2)','stroke-width':'1.2'}));
  var t=svgEl('text',{x:x,y:y+1,'text-anchor':'middle','dominant-baseline':'middle',
    fill:'#fff','font-size':'10','font-weight':'700','font-family':'monospace'});
  t.textContent=sym; svg.appendChild(t);
}

function bond(svg,x1,y1,x2,y2,dbl){
  svg.appendChild(svgEl('line',{x1:x1,y1:y1,x2:x2,y2:y2,stroke:'var(--tx2)','stroke-width':'2','stroke-linecap':'round'}));
  if(dbl){
    var dx=(y2-y1)*.1, dy=(x1-x2)*.1;
    svg.appendChild(svgEl('line',{x1:x1+dx,y1:y1+dy,x2:x2+dx,y2:y2+dy,stroke:'var(--tx2)','stroke-width':'1.2','stroke-linecap':'round'}));
  }
}

function lbl(svg,x,y,t){ var el=svgEl('text',{x:x,y:y,'text-anchor':'middle',fill:'var(--tx2)','font-size':'8'}); el.textContent=t; svg.appendChild(el); }

function dot(svg,x,y,col){ svg.appendChild(svgEl('circle',{cx:x,cy:y,r:2.5,fill:col||'var(--cyan)'})); }

function lewisHaloidro(svg){ atom(svg,100,90,'H','#FF6B47',14); bond(svg,114,90,136,90); atom(svg,150,90,'Cl','#4ADE80',17); [136,164,150,150].forEach(function(v,i){ dot(svg,i%2===0?v:150,i<2?90:i===2?73:107); }); lbl(svg,150,130,'par compartilhado + pares livres'); }

function lewisOxigenado(svg){ atom(svg,42,90,'O','#E11D48',14); bond(svg,56,90,74,90,true); atom(svg,90,90,'S','#FBBF24',17); bond(svg,106,90,124,90,true); atom(svg,140,90,'O','#E11D48',14); bond(svg,90,73,90,58); atom(svg,90,45,'O','#E11D48',14); bond(svg,90,107,90,122); atom(svg,90,135,'O','#E11D48',14); lbl(svg,91,168,'ácido oxigenado'); }

function lewisBase(svg){ atom(svg,90,85,'Na⁺','#F59E0B',18); var t=svgEl('text',{x:112,y:90,'dominant-baseline':'middle',fill:'var(--tx3)','font-size':'16'}); t.textContent='···'; svg.appendChild(t); atom(svg,148,85,'OH⁻','#4ADE80',18); lbl(svg,119,130,'atração iônica — base forte'); }

function lewisBaseFraga(svg){ atom(svg,150,80,'N','#6366F1',17); [[130,110],[150,112],[170,110]].forEach(function(p){ bond(svg,150,80,p[0],p[1]); atom(svg,p[0],p[1],'H','#94A3B8',12); }); dot(svg,148,60); dot(svg,156,60); lbl(svg,150,145,'par livre no N — base de Brønsted'); }

function lewisSal(svg){ atom(svg,88,90,'Na⁺','#F59E0B',19); var t=svgEl('text',{x:110,y:95,'dominant-baseline':'middle',fill:'var(--tx3)','font-size':'16'}); t.textContent='···'; svg.appendChild(t); atom(svg,148,90,'Cl⁻','#22C55E',19); lbl(svg,118,135,'atração eletrostática — ligação iônica'); lbl(svg,118,148,'(íons livres em solução)'); }

function lewisSalColorido(svg){ atom(svg,90,85,'Cu²⁺','#3B82F6',21); [[70,115],[90,118],[110,115],[76,55],[104,55]].forEach(function(p){ bond(svg,90,85,p[0],p[1]); var c=svgEl('circle',{cx:p[0],cy:p[1],r:7,fill:'#60A5FA',stroke:'var(--bdr2)','stroke-width':'1'}); svg.appendChild(c); var t=svgEl('text',{x:p[0],y:p[1]+1,'text-anchor':'middle','dominant-baseline':'middle',fill:'#fff','font-size':'6'}); t.textContent='H₂O'; svg.appendChild(t); }); lbl(svg,90,150,'Cu²⁺ coordena H₂O → azul intenso'); }

function lewisOxidoBasico(svg,f){ var s=f==='CaO'?'Ca²⁺':'Fe³⁺', col=f==='CaO'?'#22C55E':'#FB923C'; atom(svg,85,90,s,col,21); bond(svg,107,90,135,90,true); atom(svg,152,90,'O²⁻','#E11D48',19); lbl(svg,119,135,'óxido básico — forma base com H₂O'); }

function lewisOxidoAcido(svg,f){ if(f==='CO2'){ atom(svg,65,90,'O','#E11D48',14); bond(svg,79,90,97,90,true); atom(svg,113,90,'C','#6B7280',17); bond(svg,129,90,147,90,true); atom(svg,163,90,'O','#E11D48',14); lbl(svg,113,130,'O=C=O  linear — óxido ácido'); } else { atom(svg,75,80,'O','#E11D48',14); bond(svg,89,80,107,80,true); atom(svg,123,80,'S','#FBBF24',17); bond(svg,123,63,123,50,true); atom(svg,123,38,'O','#E11D48',14); bond(svg,139,80,157,80,true); atom(svg,173,80,'O','#E11D48',14); lbl(svg,115,130,'SO₃ — óxido ácido / pirâmide'); } }

function lewisGenerico(svg,f){ atom(svg,150,90,f.charAt(0)||'?','var(--coral)',22); lbl(svg,150,130,sub2(f)); }

