/* ═══════════════════════════════════════════════════════════════
   CAMADA: MÓDULO 3 — REDOX
   ARQUIVO: logica.js
   ───────────────────────────────────────────────────────────────
   MDC/MMC (usados no balanceamento), monta os níveis de dificuldade
   disponíveis, a lista de reações por dificuldade, a seleção de uma
   reação, e mod3RenderDetalheReacao() — a função que monta a análise
   completa (estados de oxidação, semirreações, balanceamento) exibida
   na área central.
   Depende de: data/reacoes-redox.js.
═══════════════════════════════════════════════════════════════ */

'use strict';

/* ── 7.3 Módulo 3 — Reações Redox ──────────────────────────────── */
var _mod3Dificuldades = [
  { id:'basico', label:'Básico' },
  { id:'intermediaria', label:'Intermediária' },
  { id:'avancada', label:'Avançada' },
];

var _mod3DificuldadeAtual = 'basico';

var _mod3Iniciado = false;

function mod3CalcularMDC(a,b){ return b===0 ? a : mod3CalcularMDC(b, a % b); }

function mod3CalcularMMC(a,b){ return (a*b) / mod3CalcularMDC(a,b); }

function mod3MontarDificuldades(){
  var wrap = $('difficulty-selector');
  if(!wrap) return;
  wrap.innerHTML = '';
  wrap.setAttribute('role','tablist');
  wrap.setAttribute('aria-label','Nível de dificuldade das reações redox');
  _mod3Dificuldades.forEach(function(d){
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'diff-btn' + (d.id === _mod3DificuldadeAtual ? ' diff-btn--active' : '');
    btn.setAttribute('role','tab');
    btn.setAttribute('aria-selected', d.id === _mod3DificuldadeAtual ? 'true' : 'false');
    btn.textContent = d.label;
    btn.addEventListener('click', function(){ mod3MudaDificuldade(d.id); });
    wrap.appendChild(btn);
  });
}

function mod3MudaDificuldade(dif){
  var temReacoes = REACOES_REDOX.some(function(r){ return r.dificuldade === dif; });
  if(!temReacoes){
    var d = _mod3Dificuldades.filter(function(x){ return x.id===dif; })[0];
    srAnnounce('Nível ' + (d?d.label:dif) + ' ainda não tem reações cadastradas. Em desenvolvimento.');
    return;
  }
  _mod3DificuldadeAtual = dif;
  document.querySelectorAll('#difficulty-selector .diff-btn').forEach(function(b,i){
    var ativo = _mod3Dificuldades[i].id === dif;
    b.classList.toggle('diff-btn--active', ativo);
    b.setAttribute('aria-selected', ativo ? 'true' : 'false');
  });
  mod3RenderReacoes();
  var painel = $('redox-detail-panel');
  if(painel) painel.hidden = true;
}

function mod3RenderReacoes(){
  var listDiv = $('redox-reactions-list');
  if(!listDiv) return;
  var reacoes = REACOES_REDOX.filter(function(r){ return r.dificuldade === _mod3DificuldadeAtual; });

  listDiv.innerHTML = '';
  listDiv.setAttribute('role','listbox');
  listDiv.setAttribute('aria-label','Reações redox de nível ' + _mod3DificuldadeAtual);

  if(reacoes.length === 0){
    var vazio = document.createElement('p');
    vazio.className = 'no-results';
    vazio.textContent = 'Nenhuma reação disponível neste nível ainda.';
    listDiv.appendChild(vazio);
    return;
  }

  reacoes.forEach(function(r, i){
    var item = document.createElement('div');
    item.className = 'redox-reaction-item';
    item.setAttribute('role','option');
    item.setAttribute('tabindex','0');
    item.setAttribute('aria-selected','false');
    item.innerHTML =
      '<div class="reaction-head">'+
        '<span class="reaction-num">Reação '+(i+1)+'</span>'+
        '<span class="reaction-diff">'+r.dificuldade+'</span>'+
      '</div>'+
      '<div class="reaction-title">'+r.titulo+'</div>'+
      '<code class="reaction-eq">'+r.equacao_desbalanceada+'</code>'+
      '<p class="reaction-desc">'+r.descricao+'</p>';

    function selecionar(){
      listDiv.querySelectorAll('.redox-reaction-item').forEach(function(el){ el.setAttribute('aria-selected','false'); });
      item.setAttribute('aria-selected','true');
      mod3SelecionaReacao(r);
    }
    item.addEventListener('click', selecionar);
    item.addEventListener('keydown', function(e){
      if(e.key==='Enter'||e.key===' '){ e.preventDefault(); selecionar(); }
    });
    listDiv.appendChild(item);
  });
}

function mod3SelecionaReacao(reacao){
  mod3RenderDetalheReacao(reacao);
  if(window._setView) window._setView('redox');
  srAnnounce('Reação ' + reacao.titulo + ' carregada. Analise os estados de oxidação.');
}

/* Renderiza a análise completa da reação — mesmo padrão da Ficha
   (Módulos 1/2 geram no centro via carregarComposto()): o painel
   lateral "Reações Disponíveis" é o CONTROLE (escolher a reação); a
   análise completa é GERADA na área central (#panel-redox), com mais
   espaço para a equação, os estados de oxidação, as semirreações lado
   a lado e o balanceamento — réplica do padrão de 3 camadas do SIMA
   (seletor → controles/dados na lateral → canvas central gera o
   resultado). A barra lateral mantém só um resumo compacto. */
function mod3RenderDetalheReacao(reacao){
  var mmc = mod3CalcularMMC(reacao.semireacoes.oxidacao.eletrons, reacao.semireacoes.reducao.eletrons);
  var fatorOx = mmc / reacao.semireacoes.oxidacao.eletrons;
  var fatorRed = mmc / reacao.semireacoes.reducao.eletrons;

  var estadosHtml = Object.keys(reacao.oxidacao_estados).map(function(el){
    var e = reacao.oxidacao_estados[el];
    var sinalI = e.inicial > 0 ? '+'+e.inicial : String(e.inicial);
    var sinalF = e.final > 0 ? '+'+e.final : String(e.final);
    return '<li><strong>'+el+'</strong>: NOX '+sinalI+' → '+sinalF+' (variação de '+Math.abs(e.final-e.inicial)+' unidade(s))</li>';
  }).join('');

  var coefHtml = Object.keys(reacao.coeficientes).map(function(k){
    return '<li>'+reacao.coeficientes[k]+' × '+k+'</li>';
  }).join('');

  var corpoDetalhe =
      '<p class="redox-subhead">Equação desbalanceada</p>'+
      '<code class="redox-eq-block">'+reacao.equacao_desbalanceada+'</code>'+
      '<p class="redox-subhead">Estados de oxidação (NOX)</p>'+
      '<ul class="redox-states-list">'+estadosHtml+'</ul>'+
      '<p class="redox-subhead">Semirreações</p>'+
      '<div class="half-reaction oxidacao">'+
        '<span class="half-reaction-label">⬆ Oxidação (perda de elétrons)</span>'+
        '<code>'+reacao.semireacoes.oxidacao.equacao+'</code>'+
        '<p class="half-reaction-detail">'+reacao.semireacoes.oxidacao.eletrons+' e⁻ por fórmula × fator '+fatorOx+' = '+mmc+' e⁻</p>'+
      '</div>'+
      '<div class="half-reaction reducao">'+
        '<span class="half-reaction-label">⬇ Redução (ganho de elétrons)</span>'+
        '<code>'+reacao.semireacoes.reducao.equacao+'</code>'+
        '<p class="half-reaction-detail">'+reacao.semireacoes.reducao.eletrons+' e⁻ por fórmula × fator '+fatorRed+' = '+mmc+' e⁻</p>'+
      '</div>'+
      '<p class="redox-subhead">Balanceamento</p>'+
      '<p class="redox-mmc">MMC de elétrons transferidos = <strong>'+mmc+'</strong></p>'+
      '<ul class="redox-coef-list">'+coefHtml+'</ul>'+
      '<p class="redox-subhead">Equação balanceada</p>'+
      '<code class="redox-eq-block redox-eq-final">'+reacao.equacao_balanceada+'</code>'+
      '<p class="redox-application"><strong>Aplicação:</strong> '+reacao.aplicacao+'</p>'+
      '<p class="redox-fonte"><strong>Fonte:</strong> '+reacao.fonte+'</p>';

  /* ── Central (GERADO): layout hero, igual à Ficha ── */
  var central = $('redox-central-content');
  if(central){
    central.innerHTML =
      '<div class="redox-hero">'+
        '<p class="redox-hero-label">'+reacao.dificuldade+' · '+reacao.ambiente+'</p>'+
        '<h2 class="redox-hero-title">'+reacao.titulo+'</h2>'+
        '<p class="redox-hero-desc">'+reacao.descricao+'</p>'+
      '</div>'+
      '<div class="redox-detail redox-detail--central">'+corpoDetalhe+'</div>';
  }

  /* ── Lateral (CONTROLE): resumo compacto, aponta pro centro ── */
  var painel = $('redox-detail-panel');
  if(painel){
    painel.hidden = false;
    painel.innerHTML =
      '<div class="redox-detail redox-detail--sidebar">'+
        '<p class="redox-resumo">✓ <strong>'+reacao.titulo+'</strong> selecionada — a análise completa (estados de oxidação, semirreações e balanceamento) está na área central. →</p>'+
        '<code class="redox-eq-block redox-eq-final">'+reacao.equacao_balanceada+'</code>'+
      '</div>';
  }
}

function initModulo3(){
  if(_mod3Iniciado) return;
  if(typeof REACOES_REDOX === 'undefined'){
    console.error('[modulo3] REACOES_REDOX não definido — verifique dadossiqi.js.');
    return;
  }
  _mod3Iniciado = true;
  mod3MontarDificuldades();
  mod3RenderReacoes();
}

