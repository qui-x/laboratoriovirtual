# SIQI — Simulador Interativo de Química Inorgânica
### Guia da arquitetura refatorada

## O que mudou e o que NÃO mudou

- ✅ **Nenhum dado foi alterado.** Os 100 compostos catalogados, os
  98 desafios do Construtor, o banco de reações do Laboratório
  (centenas de reações, acumuladas em 7 "expansões"), as regras
  IUPAC e as reações de redox — tudo com os mesmos valores.
- ✅ **Nenhuma funcionalidade foi alterada.** Os 3 módulos
  (Nomenclatura socrática, Construtor de nomenclatura por blocos,
  Redox com balanceamento íon-elétron), o Laboratório de reações
  livres com física de partículas, acessibilidade, menu mobile —
  tudo continua igual.
- ✅ **O projeto continua funcionando sem servidor** (`file://`), sem
  bundler.
- 📁 O que mudou foi **a organização dos arquivos**: `scriptsiqi.js`
  (2975 linhas) virou **27 arquivos** por camada/módulo.
  `dadossiqi.js` — de longe o maior arquivo de dados de toda a
  coleção de simuladores, 572 KB — virou **15 arquivos** temáticos.
  `stylesiqi.css` foi mantido intocado.

## Uma curiosidade do maior arquivo de dados da coleção

`dadossiqi.js` guarda o banco de reações do Laboratório
(`REACOES_LIVRES`) de um jeito interessante: em vez de um único
objeto gigante, o arquivo original já declarava um núcleo
(`var REACOES_LIVRES = {...}`) e depois **7 blocos autoexecutáveis**
(`(function(){ ... })()`), cada um mesclando mais reações no mesmo
banco — o comentário de cada bloco no arquivo original diz
"Reações dos compostos adicionados na expansão 2", "expansão 3" etc.,
sinal de que o catálogo foi crescendo ao longo do tempo. A
refatoração preservou exatamente essa estrutura: um arquivo
`reacoes-livres-base.js` com o núcleo, e sete arquivos
`reacoes-livres-expansao-1.js` a `-7.js`, cada um com o mesmo
bloco autoexecutável de antes — só que agora cada um é o seu próprio
arquivo, carregado em sequência.

## Por que este arquivo NÃO precisou da técnica de namespace do SILQ

Como o SIE e o SITP, o SIQI tem suas declarações soltas no escopo de
topo do arquivo (não dentro de um único closure gigante como o
SILQ). Uma checagem estática confirmou **zero casos** de função
referenciada antes de sua declaração de um jeito que dependesse de
hoisting entre arquivos.

## Como isso foi validado

- Comparação linha-a-linha entre os arquivos originais (script E
  dados) e os 42 novos — **100% idêntico**. O cabeçalho geral do
  arquivo de dados (fontes, campos, referências bibliográficas) foi
  incorporado a este README e aos cabeçalhos dos arquivos de dados
  mais relevantes, em vez de ficar de fora da comparação sem
  explicação.
- Teste funcional cobrindo os 3 módulos: ativar Nomenclatura e
  consultar um composto (H₂SO₄), alternar Lab/Ficha, ativar
  Construtor e montar um desafio, ativar Redox e analisar uma reação
  completa.
- Teste exaustivo: **os 97 compostos da Biblioteca de Nomenclatura,
  os 98 desafios do Construtor, e a reação de Redox cadastrada** —
  194 itens no total, cada um clicado e comparado entre a versão
  original e a refatorada.
- Resultado: **0 divergências**, **0 erros de JavaScript**, nas duas
  rodadas de teste.

## Mapa dos arquivos

| Arquivo | Camada | Responsabilidade |
|---|---|---|
| `js/data/metadados-funcao.js` | Dados | Funções inorgânicas + categorias |
| `js/data/catalogo-compostos.js` | Dados | 100 compostos catalogados |
| `js/data/experimentos.js` | Dados | Desafios socráticos (Nomenclatura) |
| `js/data/reacoes-livres-base.js` | Dados | Banco de reações do Lab (núcleo) |
| `js/data/reacoes-livres-expansao-1.js` … `-7.js` | Dados | Reações adicionadas em cada expansão |
| `js/data/ligantes-metais.js` | Dados | Ligantes, metais, prefixos gregos |
| `js/data/desafios-construtor.js` | Dados | 98 desafios do Construtor |
| `js/data/regras-iupac.js` | Dados | Regras de nomenclatura exibidas como guia |
| `js/data/reacoes-redox.js` | Dados | Reações de oxirredução cadastradas |
| `js/a11y/preferencias.js` | Acessibilidade | Tema/contraste/daltonismo |
| `js/core/dados-adapter.js` | Núcleo | Catálogo bruto → dicionário COMPOSTOS |
| `js/core/desbloqueio.js` | Núcleo | Compostos desbloqueados (memória) |
| `js/core/estado.js` | Núcleo | Estado global do módulo 1 |
| `js/core/dom-utils.js` | Núcleo | $ , txt, html, subscritos, anúncios |
| `js/ui/paineis.js` | Interface | Painéis recolhíveis |
| `js/ui/modal-expandir.js` | Interface | Modal de leitura ampliada |
| `js/ui/menu-mobile.js` | Interface | Gavetas mobile |
| `js/ui/canvas-particulas.js` | Interface | Canvas decorativo do Lab |
| `js/nomenclatura/biblioteca.js` | Módulo 1 | Lista de compostos + busca |
| `js/nomenclatura/desafio.js` | Módulo 1 | Desafio socrático + ficha |
| `js/render/lewis.js` | Renderização | Estrutura de Lewis em SVG |
| `js/ui/view-toggle.js` | Interface | Alternar Lab/Ficha/Redox/Construtor |
| `js/init/bootstrap-simulador.js` | Entrada parcial | Inicializações comuns |
| `js/lab/toast.js` | Laboratório | Notificações temporárias |
| `js/lab/reacoes-livres.js` | Laboratório | Abrir reação livre |
| `js/lab/parser-formula.js` | Laboratório | Parser de fórmula química |
| `js/lab/estado-fisico.js` | Laboratório | Estado físico a 25°C |
| `js/lab/builder-estado.js` | Laboratório | Estado do builder |
| `js/lab/builder-mecanica.js` | Laboratório | Bancada + estequiometria ao vivo |
| `js/lab/builder-verificacao.js` | Laboratório | Verificar reação + reiniciar |
| `js/lab/eventos.js` | Laboratório | Botões Verificar/Reiniciar |
| `js/modulos/alternar.js` | Módulos | Alternar entre os 3 módulos |
| `js/construtor/estado-biblioteca.js` | Módulo 2 | Estado + biblioteca de desafios |
| `js/construtor/bancada.js` | Módulo 2 | Bancada de montagem + validador |
| `js/redox/logica.js` | Módulo 3 | Dificuldades, reações, análise |
| `js/redox/eventos-finais.js` | Entrada | Disparo final (≈"main.js") |
| `css/stylesiqi.css` | Estilo | **Intocado** |

## Como rodar

Igual a antes: abra `indexsiqi.html` no navegador (funciona por
`file://`) ou publique a pasta inteira num servidor estático,
mantendo `css/` e `js/` (com todas as subpastas) ao lado de
`indexsiqi.html`.
