/* ═══════════════════════════════════════════════════════════════
   CAMADA: SIMULAÇÃO
   ARQUIVO: fisica-solubilidade.js
   ORIGEM:  NOVO arquivo do SIFI, mas segue o MESMO padrão de loop dos
            outros dois motores (startLoop/stopLoop com setInterval).
   ───────────────────────────────────────────────────────────────
   O coração do Módulo 3: UMA regra pareada só (`SIFI.saoCompativeis`),
   a mesma "semelhante dissolve semelhante" da especificação, medida
   numa ESCALA CONTÍNUA de polaridade (o índice de Snyder, o mesmo
   usado de verdade em química analítica pra escolher solventes de
   cromatografia — L.R. Snyder, Journal of Chromatography, 92 (1978)
   223-234) — mas agora precisa lidar com ATÉ 5 substâncias no MESMO
   tubo ao mesmo tempo, não só duas.

   COMO N SUBSTÂNCIAS VIRAM VÁRIAS FASES (`SIFI.agruparPorFase`):
   ordena as substâncias líquidas pela polaridade e anda pela lista
   ordenada, colocando cada uma no MESMO grupo da anterior se a
   diferença de polaridade entre elas estiver dentro do limite, ou
   começando um grupo novo se não estiver. É uma simplificação
   deliberada (compatibilidade nem sempre é perfeitamente transitiva
   na química real — A compatível com B, B compatível com C, não
   GARANTE que A seja compatível com C se a cadeia for longa demais),
   mas dá um resultado determinístico e previsível pro simulador, e
   funciona bem pro número de substâncias que cabem num tubo (até 5).

   Cada grupo resultante é uma FASE: todas as substâncias dali se
   misturam livremente ENTRE SI (uma "mini mistura homogênea"), e as
   fases entre si se ordenam em camadas por DENSIDADE MÉDIA (a mais
   densa embaixo) — a generalização natural de "2 líquidos
   incompatíveis formam 2 camadas" pra "N líquidos formam K fases".

   Sólidos: cada um dissolve (ou não) checando se é compatível com
   ALGUMA das fases líquidas presentes — se for, as partículas que se
   soltam do cristal vão pra banda daquela fase especificamente, não
   pro tubo inteiro.

   CASO ESPECIAL — sal (NaCl, `ionico: true`): ao dissolver, o par
   Na-Cl se SEPARA em dois íons independentes (não continua grudado
   como um sólido covalente, ex.: iodo, faria) — é assim que sal
   dissolve de verdade, em íons livres, não em "moléculas de NaCl"
   intactas (que tecnicamente nem existem).
   Depende de: js/core/estado.js, js/data/dados-forcas-intermoleculares.js,
              js/ui/prateleira.js (SIFI.estadoFisicoAmbiente),
              js/ui/menu-moleculas.js (SIFI.buildMoleculeMiniSVG).
   Usado por: js/ui/tubo-ensaio.js (SIFI.classificarTubo, ao criar um
              tubo/adicionar substância), js/init/ativacao-modulos.js
              (startLabLoop/stopLabLoop).
═══════════════════════════════════════════════════════════════ */

'use strict';

document.addEventListener('DOMContentLoaded', () => {
  /* A regra PAREADA central — "semelhante dissolve semelhante", numa
     escala contínua de polaridade, não um "polar ou apolar" binário.
     Substâncias iônicas (`ionico: true`, só o NaCl por enquanto) têm
     `polaridade` fixada BEM alta (10, acima até da água) — a atração
     íon-dipolo com um solvente polar é mais forte que a atração
     dipolo-dipolo comum entre duas moléculas polares, então sal se dá
     bem com água mas mal com qualquer coisa apolar, como na realidade. */
  SIFI.saoCompativeis = function saoCompativeis(molA, molB) {
    const diff = Math.abs(molA.polaridade - molB.polaridade);
    return diff <= SIFI.LAB_LIMITE_POLARIDADE;
  };

  /* Agrupa uma lista de moléculas LÍQUIDAS em fases — ver o cabeçalho
     do arquivo pra explicação completa do algoritmo (ordena por
     polaridade, anda pela lista juntando vizinhos compatíveis). */
  SIFI.agruparPorFase = function agruparPorFase(mols) {
    if (!mols.length) return [];
    const ordenados = mols.slice().sort((a, b) => a.polaridade - b.polaridade);
    const fases = [[ordenados[0]]];
    for (let i = 1; i < ordenados.length; i++) {
      const anterior = ordenados[i - 1], atual = ordenados[i];
      if (Math.abs(atual.polaridade - anterior.polaridade) <= SIFI.LAB_LIMITE_POLARIDADE) {
        fases[fases.length - 1].push(atual);
      } else {
        fases.push([atual]);
      }
    }
    return fases;
  };

  /* Classifica o tubo inteiro: agrupa os líquidos presentes em fases,
     ordena as fases por densidade média (mais densa embaixo), divide
     a altura do tubo em bandas — uma por fase — e reposiciona toda
     partícula líquida na banda certa (feedback visual imediato, sem
     esperar o próximo tick de física). Pra cada sólido presente,
     decide se ele é compatível com ALGUMA fase (guarda em
     `p.faseAlvo`, usado depois por dissolverParticula). */
  SIFI.classificarTubo = function classificarTubo(tubo) {
    const mols = tubo.substancias.map(k => INTERMOL_MOLECULES.find(m => m.key === k)).filter(Boolean);
    const liquidos = mols.filter(m => SIFI.estadoFisicoAmbiente(m) === 'liquido');
    const solidos = mols.filter(m => SIFI.estadoFisicoAmbiente(m) === 'solido');

    const gruposBrutos = SIFI.agruparPorFase(liquidos);
    const fases = gruposBrutos.map(grupo => ({
      mols: grupo,
      keys: grupo.map(m => m.key),
      densidadeMedia: grupo.reduce((s, m) => s + m.density, 0) / grupo.length,
    }));
    fases.sort((a, b) => a.densidadeMedia - b.densidadeMedia); // menos densa primeiro (fica em cima)

    const margem = 4, alturaTotal = 89;
    const n = Math.max(1, fases.length);
    const alturaBanda = alturaTotal / n;
    fases.forEach((fase, i) => {
      fase.yMin = margem + i * alturaBanda;
      fase.yMax = margem + (i + 1) * alturaBanda;
    });

    tubo.fases = fases;
    // Mantém .compativel como um booleano simples (true = tudo virou 1
    // fase só) — o nome antigo, mas agora generalizado pra N substâncias.
    tubo.compativel = fases.length <= 1;

    // Reposiciona as partículas LÍQUIDAS na banda da fase certa.
    tubo.particulas.forEach(p => {
      const mol = mols.find(m => m.key === p.substanciaKey);
      if (!mol || SIFI.estadoFisicoAmbiente(mol) !== 'liquido') return;
      const fase = fases.find(f => f.keys.includes(p.substanciaKey));
      if (fase) {
        p.faseMinY = fase.yMin; p.faseMaxY = fase.yMax;
        p.y = fase.yMin + Math.random() * (fase.yMax - fase.yMin);
        p.dom.style.top = p.y + '%';
      }
    });

    // Pra cada SÓLIDO, decide se é compatível com ALGUMA fase líquida
    // presente — se for, guarda ESSA fase (não só um booleano) pra
    // saber pra onde mandar as partículas quando dissolverem.
    solidos.forEach(solidoMol => {
      const faseCompativel = fases.find(f => f.mols.some(lm => SIFI.saoCompativeis(lm, solidoMol))) || null;
      tubo.particulas
        .filter(p => p.substanciaKey === solidoMol.key)
        .forEach(p => { p.faseAlvo = faseCompativel; });
    });
  };

  /* Texto explicativo do painel "Tubo Selecionado" — descreve quantas
     fases líquidas se formaram (1 = mistura homogênea; 2+ = camadas
     separadas) e o status de cada sólido presente (dissolvendo ou não). */
  SIFI.gerarTextoStatusTubo = function gerarTextoStatusTubo(tubo) {
    const mols = tubo.substancias.map(k => INTERMOL_MOLECULES.find(m => m.key === k)).filter(Boolean);
    const liquidos = mols.filter(m => SIFI.estadoFisicoAmbiente(m) === 'liquido');
    const solidos = mols.filter(m => SIFI.estadoFisicoAmbiente(m) === 'solido');
    const partes = [];

    if (liquidos.length === 1) {
      partes.push(`<strong>${liquidos[0].name}</strong> sozinha no tubo.`);
    } else if (liquidos.length > 1) {
      if (tubo.fases.length <= 1) {
        const nomes = liquidos.map(m => m.name).join(', ');
        partes.push(
          `<strong>Mistura homogênea!</strong> ${nomes} — todos compatíveis ` +
          `(dentro do limite de polaridade), uma fase só.`
        );
      } else {
        partes.push(
          `<strong>${tubo.fases.length} camadas separadas.</strong> Os líquidos se agruparam ` +
          `por polaridade parecida, ordenados por densidade (a mais densa embaixo).`
        );
      }
    }

    solidos.forEach(s => {
      const particula = tubo.particulas.find(p => p.substanciaKey === s.key);
      const dissolvendo = particula && !!particula.faseAlvo;
      partes.push(dissolvendo
        ? `<strong>${s.name}</strong> está dissolvendo aos poucos.`
        : `<strong>${s.name}</strong> não dissolve em nada presente — fica intacto no fundo.`);
    });

    return partes.join(' ');
  };

  /* ===================================================================
     DISSOLVER UMA PARTÍCULA DE CRISTAL — solta do amontoado e passa a
     se mover livre DENTRO DA BANDA da fase compatível (`p.faseAlvo`,
     calculado por SIFI.classificarTubo). Se a substância for IÔNICA,
     além disso se separa em DOIS íons independentes.
     =================================================================== */
  function dissolverParticula(tubo, p, mol) {
    p.estadoNoTubo = 'dissolvida';
    p.dom.classList.remove('tubo-particula--cristal');
    p.vx = 0; p.vy = 0;

    const fase = p.faseAlvo;
    p.x = 15 + Math.random() * 70;
    if (fase) {
      p.y = fase.yMin + Math.random() * (fase.yMax - fase.yMin);
      p.faseMinY = fase.yMin; p.faseMaxY = fase.yMax;
    } else {
      p.y = 10 + Math.random() * 70;
    }
    p.dom.style.left = p.x + '%';
    p.dom.style.top = p.y + '%';

    if (mol.ionico) {
      SIFI.separarEmIons(tubo, p, mol);
    }
  }

  /* Troca UMA partícula "par iônico" (ex.: NaCl inteiro) por DUAS
     partículas de um único íon cada (Na sozinho, Cl sozinho) — cada
     "molécula-fantasma" de 1 átomo só é montada na hora, reaproveitando
     a MESMA SIFI.buildMoleculeMiniSVG que desenha moléculas de verdade
     (ela não se importa se a "molécula" tem 1 ou 20 átomos). Os dois
     íons herdam a mesma banda de fase (`faseMinY`/`faseMaxY`) da
     partícula original. Exposta em SIFI.* pra poder testar isoladamente. */
  SIFI.separarEmIons = function separarEmIons(tubo, parIonico, mol) {
    const idx = tubo.particulas.indexOf(parIonico);
    if (idx === -1) return;

    parIonico.dom.remove();
    tubo.particulas.splice(idx, 1);

    mol.atoms.forEach((atomo, i) => {
      const ionMol = { atoms: [{ el: atomo.el, x: 0, y: 0 }], bonds: [] };
      const dom = document.createElement('div');
      dom.className = 'tubo-particula tubo-particula--ion';
      dom.style.setProperty('--particula-cor', FORCE_TYPES[mol.dominantForce].color);
      dom.innerHTML = SIFI.buildMoleculeMiniSVG(ionMol, false);
      dom.setAttribute('aria-hidden', 'true');

      const x = Math.min(90, Math.max(10, parIonico.x + (Math.random() - 0.5) * 12));
      const y = Math.min(90, Math.max(10, parIonico.y + (Math.random() - 0.5) * 12));
      dom.style.left = x + '%';
      dom.style.top = y + '%';
      if (tubo.dom.particulasEl) tubo.dom.particulasEl.appendChild(dom);

      tubo.particulas.push({
        id: `${parIonico.id}-ion${i}`, substanciaKey: mol.key,
        estadoFisico: 'solido', estadoNoTubo: 'dissolvida',
        x, y, vx: 0, vy: 0, dom, ionDe: atomo.el,
        faseMinY: parIonico.faseMinY, faseMaxY: parIonico.faseMaxY,
      });
    });
  };

  /* ===================================================================
     TICK DE FÍSICA — roda pra TODOS os tubos existentes ao mesmo tempo
     (2 ou até 10, o que quer que exista no momento).
     =================================================================== */
  SIFI.labTick = function labTick() {
    if (!SIFI.laboratorio.rodando) return;

    SIFI.laboratorio.tubos.forEach(tubo => {
      if (!tubo.substancias.length) return;
      const mols = tubo.substancias.map(k => INTERMOL_MOLECULES.find(m => m.key === k)).filter(Boolean);

      tubo.particulas.forEach(p => {
        const mol = mols.find(m => m.key === p.substanciaKey);
        if (!mol) return;

        if (p.estadoNoTubo === 'cristal') {
          // Vibra em volta do monte do cristal (mesma ideia do sólido
          // do Módulo 2) — só se solta se tiver uma fase compatível.
          const jitterX = (Math.random() - 0.5) * 0.5;
          p.dom.style.left = (p.x + jitterX) + '%';
          if (p.faseAlvo && Math.random() < SIFI.LAB_CHANCE_DISSOLVER) {
            dissolverParticula(tubo, p, mol);
          }
          return;
        }

        // Dispersa (líquido normal OU sólido já dissolvido): balança
        // livre, mas confinada na SUA banda de fase (se tiver uma) —
        // é isso que MANTÉM fases diferentes separadas com o tempo.
        p.vx = (p.vx + (Math.random() - 0.5) * 0.35) * 0.85;
        p.vy = (p.vy + (Math.random() - 0.5) * 0.35) * 0.85;
        p.x = Math.min(92, Math.max(8, p.x + p.vx));

        if (p.faseMinY !== undefined && p.faseMaxY !== undefined) {
          p.y = Math.min(p.faseMaxY, Math.max(p.faseMinY, p.y + p.vy));
        } else {
          p.y = Math.min(93, Math.max(4, p.y + p.vy));
        }

        p.dom.style.left = p.x + '%';
        p.dom.style.top = p.y + '%';
      });
    });
  };

  SIFI.startLabLoop = function startLabLoop() {
    if (SIFI.simLoopLab) return;
    SIFI.laboratorio.rodando = true;
    SIFI.simLoopLab = setInterval(SIFI.labTick, SIFI.LAB_DT);
  };

  SIFI.stopLabLoop = function stopLabLoop() {
    if (SIFI.simLoopLab) { clearInterval(SIFI.simLoopLab); SIFI.simLoopLab = null; }
    SIFI.laboratorio.rodando = false;
  };
});
