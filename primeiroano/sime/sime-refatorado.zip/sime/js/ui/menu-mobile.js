/* ═══════════════════════════════════════════════════════════════
   CAMADA: INTERFACE (interação)
   ARQUIVO: menu-mobile.js
   ───────────────────────────────────────────────────────────────
   Controla a abertura/fechamento das gavetas laterais em telas
   estreitas (botões ☰ e ⚙ no cabeçalho, com pano de fundo clicável).
   Depende de: nada além do HTML.
   Usado por: main.js.
═══════════════════════════════════════════════════════════════ */

'use strict';

/* ═══════════════════════════════════════════════════════
   MENU MOBILE
═══════════════════════════════════════════════════════ */
function initMobileMenu() {
  var btnL  = document.getElementById('mobile-menu-btn');
  var btnR  = document.getElementById('mobile-menu-btn-right');
  var left  = document.getElementById('sidebar-left');
  var right = document.getElementById('sidebar-right');
  var bd    = document.getElementById('mobile-backdrop');
  function fechar() {
    if (left)  left.classList.remove('mobile-open');
    if (right) right.classList.remove('mobile-open');
    if (bd)    bd.hidden = true;
    if (btnL)  btnL.setAttribute('aria-expanded','false');
    if (btnR)  btnR.setAttribute('aria-expanded','false');
  }
  if (btnL) btnL.addEventListener('click', function() {
    var aberto = left && left.classList.contains('mobile-open');
    fechar();
    if (!aberto && left) { left.classList.add('mobile-open'); if (bd) bd.hidden=false; btnL.setAttribute('aria-expanded','true'); }
  });
  if (btnR) btnR.addEventListener('click', function() {
    var aberto = right && right.classList.contains('mobile-open');
    fechar();
    if (!aberto && right) { right.classList.add('mobile-open'); if (bd) bd.hidden=false; btnR.setAttribute('aria-expanded','true'); }
  });
  if (bd) bd.addEventListener('click', fechar);
}
